// Databricks notebook source
// Databricks Utilities (dbutils) reference https://docs.databricks.com/en/dev-tools/databricks-utils.html#language-scala

// COMMAND ----------

dbutils.help()

// COMMAND ----------

dbutils.fs.help()

// COMMAND ----------

dbutils.fs.help("cp")

// COMMAND ----------

dbutils.fs.cp("/Volumes/main/default/my-volume/data.csv", "/Volumes/main/default/my-volume/new-data.csv")

// COMMAND ----------

dbutils.fs.help("rm")

// COMMAND ----------

dbutils.fs.rm("/FileStore/tables/ravidata/silverdefault",recurse=true)

// COMMAND ----------


