// Databricks notebook source
val flightDF7 = spark.read.parquet("/FileStore/tables/ravitest/parquet")

// COMMAND ----------

flightDF7.printSchema()

// COMMAND ----------

flightDF7.show(5)

// COMMAND ----------

val flightDF7 = spark.read.format("delta").load("/FileStore/tables/ravitest/silver")

// COMMAND ----------

flightDF7.printSchema()

// COMMAND ----------

flightDF7.count()
flightDF7.show(5,false)

// COMMAND ----------

flightDF7.filter(col("cancelled")===1).groupBy("originName").agg(count("cancelled").as("cancel_count")).orderBy(col("cancel_count").desc).show()

// COMMAND ----------

val fDF8=flightDF7.filter(col("cancelled")===1).groupBy("originName").agg(count("cancelled").as("cancel_count")).orderBy(col("cancel_count").desc)

// COMMAND ----------

fDF8.show()

// COMMAND ----------

fDF8.write.save("/FileStore/tables/ravitest/gold/res1")

// COMMAND ----------

val fDF9=flightDF7.filter(col("cancelled")===1).groupBy("cancelReason").agg(count("cancelled").as("cancel_count")).orderBy(col("cancel_count").desc)


// COMMAND ----------

fDF9.show()

// COMMAND ----------

fDF8.write.save("/FileStore/tables/ravitest/gold/res2")

// COMMAND ----------

flightDF7.filter(col("cancelled")===1).groupBy("month").agg(count("cancelled").as("cancel_count")).orderBy(col("cancel_count").desc).show()

// COMMAND ----------

flightDF7.filter(col("diverted")==="Yes").count() 

// COMMAND ----------

flightDF7.filter(col("diverted")==="Yes").groupBy("destName").agg(count("diverted").as("divert_count")).orderBy(col("divert_count").desc).show(false)
