// Databricks notebook source
val airportDF = spark.read.format("csv").option("inferSchema", "true").option("header","true").load("/FileStore/tables/ravitest/bronze/airportdata.csv")
airportDF.count()
airportDF.show(5,false)

// COMMAND ----------

airportDF.printSchema()

// COMMAND ----------

val flightDF = spark.read.format("csv").option("inferSchema", "true").option("header","true").load("/FileStore/tables/ravitest/bronze/flightdata.csv")

// COMMAND ----------

flightDF.printSchema()

// COMMAND ----------

flightDF.count()
flightDF.show(5,false)

// COMMAND ----------

airportDF.describe().show()

// COMMAND ----------

flightDF.describe().show()

// COMMAND ----------

flightDF.describe("distance").show()

// COMMAND ----------

flightDF.select(col("airTime"),col("arrivalDelay")).show(30)

// COMMAND ----------

flightDF.filter(col("airTime")==="NA").select(col("airTime"),col("arrivalDelay")).show()

// COMMAND ----------

flightDF.filter(col("airTime")==="NA").count()

// COMMAND ----------

flightDF.printSchema()

// COMMAND ----------

val flightDF2=flightDF.where(col("airTime") =!= "NA").withColumn("airTime",col("airTime").cast("Integer")).withColumn("arrivalDelay",col("arrivalDelay").cast("Integer"))

// COMMAND ----------

flightDF2.printSchema()

// COMMAND ----------

flightDF2.count()

// COMMAND ----------

val flightDF3 = flightDF2.withColumn("month",(month(col("startDate"))))
flightDF3.printSchema()
flightDF3.show()

// COMMAND ----------

val flightDF4=flightDF3.withColumn("cancelReason", when( col("cancellationCode").equalTo(1),lit("carrier")).when( col("cancellationCode").equalTo(2),lit("weather")).when( col("cancellationCode").equalTo(3),lit("NAS")).when( col("cancellationCode").equalTo(4),lit("security")).otherwise(col("cancellationCode")) )
flightDF4.printSchema()
flightDF4.show()

// COMMAND ----------

airportDF.printSchema()

// COMMAND ----------

val flightDF5 = flightDF4.join(airportDF,flightDF4("origin")===airportDF("code"), "inner").withColumnRenamed("code","originCode").withColumnRenamed("name","originName").withColumnRenamed("areaCode","originAreaCode")
flightDF5.printSchema()
flightDF5.show(5,false)


// COMMAND ----------

val flightDF6 = flightDF5.join(airportDF,flightDF5("destination")===airportDF("code"), "inner").withColumnRenamed("code","destCode").withColumnRenamed("name","destName").withColumnRenamed("areaCode","destAreaCode")
flightDF6.printSchema()
flightDF6.show(5,false)

// COMMAND ----------

flightDF6.columns

// COMMAND ----------

flightDF6.write.save("/FileStore/tables/ravitest/silver")

// COMMAND ----------

flightDF6.write.parquet("/FileStore/tables/ravitest/parquet")

// COMMAND ----------


